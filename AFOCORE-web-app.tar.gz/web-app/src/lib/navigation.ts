export const navItems = [
    { path: '/dashboard', label: 'Dashboard' },
    { path: '/expedientes', label: 'Expedientes' },
    { path: '/normativa', label: 'Normativa' },
    { path: '/documentos', label: 'Documentos' },
    { path: '/finanzas', label: 'Finanzas' }
]
